---
name: Trợ lý Pháp lý
colors:
  surface: '#f7faf8'
  surface-dim: '#d7dbd9'
  surface-bright: '#f7faf8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f3'
  surface-container: '#ebefed'
  surface-container-high: '#e5e9e7'
  surface-container-highest: '#e0e3e1'
  on-surface: '#181c1c'
  on-surface-variant: '#3e4947'
  inverse-surface: '#2d3130'
  inverse-on-surface: '#eef1f0'
  outline: '#6e7977'
  outline-variant: '#bdc9c6'
  surface-tint: '#006a63'
  primary: '#005c55'
  on-primary: '#ffffff'
  primary-container: '#0f766e'
  on-primary-container: '#a3faef'
  inverse-primary: '#80d5cb'
  secondary: '#555e74'
  on-secondary: '#ffffff'
  secondary-container: '#d7dff9'
  on-secondary-container: '#5a6278'
  tertiary: '#7f4025'
  on-tertiary: '#ffffff'
  tertiary-container: '#9c573a'
  on-tertiary-container: '#ffe5db'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9cf2e8'
  primary-fixed-dim: '#80d5cb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#00504a'
  secondary-fixed: '#d9e2fc'
  secondary-fixed-dim: '#bdc6e0'
  on-secondary-fixed: '#121b2e'
  on-secondary-fixed-variant: '#3e475b'
  tertiary-fixed: '#ffdbce'
  tertiary-fixed-dim: '#ffb598'
  on-tertiary-fixed: '#370e00'
  on-tertiary-fixed-variant: '#72361b'
  background: '#f7faf8'
  on-background: '#181c1c'
  surface-variant: '#e0e3e1'
typography:
  greeting-hero:
    fontFamily: Noto Serif
    fontSize: 40px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.02em
  greeting-hero-mobile:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  body-main:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-strong:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '600'
    lineHeight: '1.6'
  sidebar-label:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.5'
  caption:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.4'
  button:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  sidebar-expanded: 264px
  sidebar-collapsed: 64px
  message-max-width: 760px
  drawer-width: 400px
  gutter: 24px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
The design system focuses on clarity, authority, and tranquility. Given the complexity of legal research, the UI acts as a silent partner—removing cognitive load through a **Minimalist** and **Corporate Modern** aesthetic. The interface prioritizes readability and structural honesty over decorative elements.

The emotional response should be one of "quiet confidence." By utilizing a nearly-white canvas and a muted sidebar, the design directs all focus toward the conversation. It employs a high degree of whitespace and avoids heavy shadows to maintain a lightweight, digital-paper feel suitable for long-form reading and precise legal analysis.

## Colors
The palette is rooted in professional stability. 

- **Main Canvas:** A warm off-white (#FCFCFA) reduces eye strain during intensive reading compared to pure white.
- **Sidebar:** A distinct but subtle grey-tinted neutral (#F1F2EF) provides clear structural hierarchy without harsh transitions.
- **Typography:** Primary text uses a deep navy-charcoal (#172033) for maximum contrast, while secondary metadata uses a softened slate (#667085).
- **Accent:** Teal (#0F766E) is used sparingly for primary actions and indications of focus, representing growth and wisdom.
- **States:** Selection uses a soft teal-grey wash (#E7ECEB). Borders are kept light (#E2E4E8) to remain invisible until needed for definition.

## Typography
The system uses a dual-font strategy tailored for the Vietnamese language. 

- **Be Vietnam Pro** is the workhorse font, specifically chosen for its excellent diacritic handling and modern humanist character. It is used for all functional UI elements, messages, and navigation.
- **Noto Serif** is reserved exclusively for high-level "Empty State" greetings. This adds a touch of traditional legal scholarship and literary prestige to the initial interaction before transitioning into the utilitarian research phase.
- **Line Height:** A generous 1.6 ratio is applied to body text to prevent diacritic crowding, ensuring that multi-line Vietnamese legal citations remain highly legible.

## Layout & Spacing
The layout follows a "Focused Stream" model. 

- **The Sidebar:** Fixed to the left, acting as the navigation anchor. It transitions between 264px and 64px.
- **The Chat Stream:** Centered on the canvas with a maximum width of 760px. This width is optimized for reading speed and ensures the line length doesn't fatigue the eye.
- **Source Drawer:** A secondary surface that emerges from the right to provide citations and document previews.
- **Rhythm:** A 4px/8px base grid governs all padding. Large margins (32px+) are used between the chat bubbles and the screen edges to reinforce the minimal, calm aesthetic.

## Elevation & Depth
This design system avoids traditional shadows to maintain a "flat-plus" look. 

- **Tonal Separation:** Depth is primarily communicated through background color changes (e.g., #F1F2EF for the sidebar vs #FCFCFA for the canvas).
- **Borders:** Subtle 1px lines (#E2E4E8) define the boundaries of the sidebar, drawer, and input areas.
- **Interactivity:** Elements do not "lift" on hover; instead, they change fill color to #E7ECEB. 
- **Modals & Drawers:** When the Source Drawer is active, a very soft, diffused 5% opacity shadow may be used to separate it from the main stream, though a vertical border is preferred.

## Shapes
The shape language is "Soft" (4px - 8px radius). This avoids the clinical harshness of sharp corners while remaining more professional than highly rounded "bubble" designs. 

- **Input Fields & Buttons:** 8px (rounded-lg) for a modern, approachable feel.
- **Message Bubbles:** Use a very slight radius (8px) rather than pills to look more like organized "cards" of information rather than casual text messages.
- **Selection States:** 6px radius for items within the sidebar.

## Components

- **Sidebar:** Contains "Cuộc hội thoại mới" (New Chat) as the primary action at the top. Items use 14px text. Active states use #E7ECEB fill with a 2px Teal left-border accent.
- **Message Bubbles:**
    - *User:* Right-aligned or full-width, subtle background or transparent with a top border.
    - *Agent:* Left-aligned, no background, primary text. Uses progressive disclosure (expandable "Xem nguồn" / View Sources) at the bottom of the response.
- **Input Area:** A persistent text area at the bottom of the chat stream. It should expand vertically. The primary action (Send) is a simple Teal icon button.
- **Legal Source Drawer:** Appears on the right. Displays "Văn bản pháp luật" (Legal Documents) with bold titles and greyed-out metadata.
- **Icons:** Use Lucide-style (2px stroke) icons exclusively. Icons should be monochrome (#667085), only changing to Teal when active.
- **Buttons:** 
    - *Primary:* Solid Teal fill (#0F766E), White text. 
    - *Secondary:* Ghost style, Teal text, no border unless hovered.